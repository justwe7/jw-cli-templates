export default definePageConfig({
  navigationBarTitleText: '下载',
})

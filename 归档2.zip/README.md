## taro3.5.x开发模板
[react@18](https://zh-hans.reactjs.org/) + typescript + [@antmjs/vantui](https://antmjs.github.io/vantui/#/button)

## TODOLIST
- [x] 全局方法
- [x] 数据持久化
- [x] eslint&autofix
- [x] stylint&autofix

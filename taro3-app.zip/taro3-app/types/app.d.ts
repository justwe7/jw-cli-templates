// import Taro from '@tarojs/taro'

// declare module '@tarojs/TaroStatic' {

//     let $globalState: any

// }
